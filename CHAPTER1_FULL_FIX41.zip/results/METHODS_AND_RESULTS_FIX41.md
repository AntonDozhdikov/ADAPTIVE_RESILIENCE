# Итог вычислительного эксперимента FIX4.1 FINAL

**Статус:** `OK_WITH_WARNINGS`
**Приемочный уровень:** `READY_FOR_FINAL_ACCEPTANCE`

## Основные счетчики

- **status:** OK_WITH_WARNINGS
- **acceptance_level:** READY_FOR_FINAL_ACCEPTANCE
- **warnings:** clusters=MODERATE
- **expectation_group_rows:** 700
- **core_2026_overall:** 16
- **expectation_annual_rows:** 40
- **trend_rows:** 4
- **changepoint_rows:** 7
- **changepoint_engine:** EXACT_DP_L2
- **gap_exact_permutation_tests:** 4
- **anxiety_history_rows:** 500
- **anxiety_current_rows:** 1750
- **anxiety_trend_rows:** 50
- **validation_rows:** 175
- **validation_tests:** 20
- **validation_fdr_sig:** 6
- **validation_robust_fdr_sig:** 6
- **cross_component_tests:** 60
- **cross_component_fdr_sig:** 0
- **cluster_groups:** 34
- **cluster_status:** MODERATE
- **micro_candidates:** 0
- **ml_status:** SKIPPED_NO_MICRODATA
- **figures:** 14
- **canonical_rows:** 5297
- **source_modes:** {"anxiety_current": "LIVE", "anxiety_history": "LIVE", "expectation_history": "LIVE", "expectations": "LIVE", "validation": "LIVE"}
- **snapshot_used:** False

## Приемочный чек-лист

| check                            | status   | detail                                                                                                                                                                                                                                                                                                                                                                                                         |
|:---------------------------------|:---------|:---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| four_expectation_constructs      | PASS     | ['country_long', 'country_short', 'family_long', 'family_short']                                                                                                                                                                                                                                                                                                                                               |
| core_2026_16_of_16               | PASS     | 16                                                                                                                                                                                                                                                                                                                                                                                                             |
| history_2017_2026_all_constructs | PASS     | {'country_long': 10, 'country_short': 10, 'family_long': 10, 'family_short': 10}                                                                                                                                                                                                                                                                                                                               |
| three_anxiety_levels             | PASS     | ['country', 'personal', 'world']                                                                                                                                                                                                                                                                                                                                                                               |
| small_n_permutation_tests        | PASS     | [{'comparison': 'macro_micro_short', 'n': 5, 'test_method': 'EXACT_PERMUTATION'}, {'comparison': 'macro_micro_long', 'n': 5, 'test_method': 'EXACT_PERMUTATION'}, {'comparison': 'horizon_country', 'n': 5, 'test_method': 'EXACT_PERMUTATION'}, {'comparison': 'horizon_family', 'n': 5, 'test_method': 'EXACT_PERMUTATION'}]                                                                                 |
| changepoint_method_exact_dp      | PASS     | ['EXACT_DP_L2']                                                                                                                                                                                                                                                                                                                                                                                                |
| cluster_no_imputation            | PASS     | 0                                                                                                                                                                                                                                                                                                                                                                                                              |
| cluster_not_unstable             | PASS     | MODERATE                                                                                                                                                                                                                                                                                                                                                                                                       |
| blocked_validation               | PASS     | tests=20, blocks=180                                                                                                                                                                                                                                                                                                                                                                                           |
| cross_component_permutation_fdr  | PASS     | tests=60                                                                                                                                                                                                                                                                                                                                                                                                       |
| source_provenance                | PASS     | [{'block': 'expectations', 'mode': 'LIVE'}, {'block': 'expectations', 'mode': 'LIVE'}, {'block': 'expectations', 'mode': 'LIVE'}, {'block': 'expectations', 'mode': 'LIVE'}, {'block': 'expectations', 'mode': 'LIVE'}, {'block': 'expectation_history', 'mode': 'LIVE'}, {'block': 'anxiety_current', 'mode': 'LIVE'}, {'block': 'anxiety_history', 'mode': 'LIVE'}, {'block': 'validation', 'mode': 'LIVE'}] |

## Контроль качества

| check                      | status   | value                                                                                                                       | detail              |
|:---------------------------|:---------|:----------------------------------------------------------------------------------------------------------------------------|:--------------------|
| exact_four_constructs      | PASS     | ['country_long', 'country_short', 'family_long', 'family_short']                                                            |                     |
| no_missing_subject_horizon | PASS     | 0                                                                                                                           |                     |
| core_2026_16_of_16         | PASS     | 16                                                                                                                          |                     |
| response_sum_near_100      | PASS     | 0.7518796992481214                                                                                                          |                     |
| core_fieldwork_dates       | PASS     | 0                                                                                                                           |                     |
| history_2017_2026          | PASS     | {'country_long': 10, 'country_short': 10, 'family_long': 10, 'family_short': 10}                                            |                     |
| anchor_15317_family_short  | PASS     | 30.73364177131527                                                                                                           | ref=30.733641771315 |
| anchor_15317_family_long   | PASS     | 32.46073298429319                                                                                                           | ref=32.460732984293 |
| anchor_15380_family_short  | PASS     | 19.287634408602152                                                                                                          | ref=19.287634408602 |
| anchor_15380_family_long   | PASS     | 25.721784776902886                                                                                                          | ref=25.721784776903 |
| html_binary_reconciliation | PASS     | 0.7336417713152699                                                                                                          | matched=16/16       |
| anxiety_three_levels_2026  | PASS     | ['country', 'personal', 'world']                                                                                            |                     |
| anxiety_items_2026         | PASS     | {'country': 17, 'personal': 17, 'world': 16}                                                                                |                     |
| anxiety_history_depth      | PASS     | {'country': 10, 'personal': 10, 'world': 10}                                                                                |                     |
| no_group_share_as_anxiety  | PASS     |                                                                                                                             |                     |
| validation_five_metrics    | PASS     | {'current_global_attitude': 35, 'developed_country': 35, 'global_attitude': 35, 'global_influence': 35, 'rich_country': 35} |                     |
| validation_group_rows      | PASS     | 170                                                                                                                         |                     |

## Макро/микро и горизонты: exact/permutation

| comparison        |   n |   spearman_rho |   p_value_perm |   p_value_asymptotic | test_method       |   permutations |   q_fdr_perm | significant_fdr_05   |
|:------------------|----:|---------------:|---------------:|---------------------:|:------------------|---------------:|-------------:|:---------------------|
| macro_micro_short |   5 |            1   |      0.0166667 |          1.40427e-24 | EXACT_PERMUTATION |            120 |    0.0666667 | False                |
| macro_micro_long  |   5 |            0.9 |      0.0833333 |          0.0373861   | EXACT_PERMUTATION |            120 |    0.166667  | False                |
| horizon_country   |   5 |            0.2 |      0.783333  |          0.74706     | EXACT_PERMUTATION |            120 |    0.95      | False                |
| horizon_family    |   5 |           -0.1 |      0.95      |          0.872889    | EXACT_PERMUTATION |            120 |    0.95      | False                |

## Theil–Sen

| construct     |   n |   year_min |   year_max |   slope_pp_per_year |    ci_low |   ci_high |   intercept | direction   |
|:--------------|----:|-----------:|-----------:|--------------------:|----------:|----------:|------------:|:------------|
| country_long  |  10 |       2017 |       2026 |            2        | -2.58542  |   5.17812 |    -4025.12 | uncertain   |
| country_short |  10 |       2017 |       2026 |            2.60714  | -0.310069 |   6       |    -5263.71 | uncertain   |
| family_long   |  10 |       2017 |       2026 |            0.857143 | -1.83333  |   3       |    -1698.59 | uncertain   |
| family_short  |  10 |       2017 |       2026 |            1.5      | -0.277778 |   4       |    -3010.5  | uncertain   |

## Change-point: EXACT_DP_L2

| construct     | engine      |   cp_year |   penalty_hits |   penalty_min |   penalty_max |   stability_share | stable   |
|:--------------|:------------|----------:|---------------:|--------------:|--------------:|------------------:|:---------|
| country_long  | EXACT_DP_L2 |      2019 |              1 |           0.5 |           0.5 |          0.142857 | False    |
| country_long  | EXACT_DP_L2 |      2022 |              7 |           0.5 |           3   |          1        | True     |
| country_short | EXACT_DP_L2 |      2022 |              6 |           0.5 |           2   |          0.857143 | True     |
| family_long   | EXACT_DP_L2 |      2019 |              1 |           0.5 |           0.5 |          0.142857 | False    |
| family_long   | EXACT_DP_L2 |      2022 |              6 |           0.5 |           2   |          0.857143 | True     |
| family_long   | EXACT_DP_L2 |      2025 |              1 |           0.5 |           0.5 |          0.142857 | False    |
| family_short  | EXACT_DP_L2 |      2023 |              6 |           0.5 |           2   |          0.857143 | True     |

## Устойчивость кластеров

|   k |   silhouette |   bootstrap_n |   ari_mean |   ari_median |   ari_ci_low |   ari_ci_high |   loo_ari_mean |   seed_ari_mean | status   |   groups_n |   features_n |   imputed_cells |   coverage_threshold |
|----:|-------------:|--------------:|-----------:|-------------:|-------------:|--------------:|---------------:|----------------:|:---------|-----------:|-------------:|----------------:|---------------------:|
|   3 |     0.372921 |           500 |   0.773963 |     0.773134 |      0.53826 |             1 |       0.910637 |        0.879374 | MODERATE |         34 |           20 |               0 |                  0.8 |

## Внешняя валидизация: стратифицированный permutation

| validation_metric       | expectation_construct   |   matched_n |   group_types_n |   stratified_rho |   p_value_perm | test_method                            |   permutations |   sign_consistency |   loo_rho_min |   loo_rho_max |   fieldwork_lag_days |   q_fdr_perm | significant_fdr_05   | robust_fdr_05   |
|:------------------------|:------------------------|------------:|----------------:|-----------------:|---------------:|:---------------------------------------|---------------:|-------------------:|--------------:|--------------:|---------------------:|-------------:|:---------------------|:----------------|
| current_global_attitude | country_long            |          34 |               5 |       -0.209158  |     0.340183   | STRATIFIED_WITHIN_BLOCK_MC_PERMUTATION |          20000 |                0.8 |    -0.473243  |    -0.0919048 |                   42 |    0.486476  | False                | False           |
| current_global_attitude | country_short           |          34 |               5 |        0.192491  |     0.389181   | STRATIFIED_WITHIN_BLOCK_MC_PERMUTATION |          20000 |                0.6 |     0.0240363 |     0.300216  |                   35 |    0.486476  | False                | False           |
| current_global_attitude | family_long             |          34 |               5 |        0.205495  |     0.359082   | STRATIFIED_WITHIN_BLOCK_MC_PERMUTATION |          20000 |                0.6 |     0.0401361 |     0.481429  |                   42 |    0.486476  | False                | False           |
| current_global_attitude | family_short            |          34 |               5 |        0.489377  |     0.0224989  | STRATIFIED_WITHIN_BLOCK_MC_PERMUTATION |          20000 |                0.8 |     0.368254  |     0.764762  |                   35 |    0.0562472 | False                | False           |
| developed_country       | country_long            |          34 |               5 |        0.539377  |     0.0104995  | STRATIFIED_WITHIN_BLOCK_MC_PERMUTATION |          20000 |                1   |     0.429705  |     0.624048  |                   42 |    0.0474976 | True                 | True            |
| developed_country       | country_short           |          34 |               5 |        0.52033   |     0.0142493  | STRATIFIED_WITHIN_BLOCK_MC_PERMUTATION |          20000 |                1   |     0.406122  |     0.592857  |                   35 |    0.0474976 | True                 | True            |
| developed_country       | family_long             |          34 |               5 |        0.658059  |     0.00139993 | STRATIFIED_WITHIN_BLOCK_MC_PERMUTATION |          20000 |                1   |     0.548413  |     0.846905  |                   42 |    0.0139993 | True                 | True            |
| developed_country       | family_short            |          34 |               5 |        0.497436  |     0.019949   | STRATIFIED_WITHIN_BLOCK_MC_PERMUTATION |          20000 |                1   |     0.377778  |     0.707937  |                   35 |    0.0562472 | False                | False           |
| global_attitude         | country_long            |          34 |               5 |        0.204212  |     0.362982   | STRATIFIED_WITHIN_BLOCK_MC_PERMUTATION |          20000 |                0.6 |     0.0147392 |     0.445476  |                   42 |    0.486476  | False                | False           |
| global_attitude         | country_short           |          34 |               5 |        0.531136  |     0.0131993  | STRATIFIED_WITHIN_BLOCK_MC_PERMUTATION |          20000 |                1   |     0.419501  |     0.619048  |                   35 |    0.0474976 | True                 | True            |
| global_attitude         | family_long             |          34 |               5 |        0.0342491 |     0.874656   | STRATIFIED_WITHIN_BLOCK_MC_PERMUTATION |          20000 |                0.6 |    -0.278571  |     0.310238  |                   42 |    0.874656  | False                | False           |
| global_attitude         | family_short            |          34 |               5 |        0.162821  |     0.466227   | STRATIFIED_WITHIN_BLOCK_MC_PERMUTATION |          20000 |                0.6 |    -0.0365079 |     0.337879  |                   35 |    0.548502  | False                | False           |
| global_influence        | country_long            |          34 |               5 |        0.13663   |     0.543023   | STRATIFIED_WITHIN_BLOCK_MC_PERMUTATION |          20000 |                0.6 |    -0.0777778 |     0.357619  |                   42 |    0.603359  | False                | False           |
| global_influence        | country_short           |          34 |               5 |        0.350549  |     0.113344   | STRATIFIED_WITHIN_BLOCK_MC_PERMUTATION |          20000 |                0.6 |     0.219728  |     0.461491  |                   35 |    0.226689  | False                | False           |
| global_influence        | family_long             |          34 |               5 |       -0.194505  |     0.387881   | STRATIFIED_WITHIN_BLOCK_MC_PERMUTATION |          20000 |                0.8 |    -0.455102  |    -0.0480519 |                   42 |    0.486476  | False                | False           |
| global_influence        | family_short            |          34 |               5 |       -0.0675824 |     0.761312   | STRATIFIED_WITHIN_BLOCK_MC_PERMUTATION |          20000 |                0.6 |    -0.297959  |     0.101948  |                   35 |    0.801381  | False                | False           |
| rich_country            | country_long            |          34 |               5 |        0.577839  |     0.00689966 | STRATIFIED_WITHIN_BLOCK_MC_PERMUTATION |          20000 |                1   |     0.501134  |     0.686508  |                   42 |    0.0459977 | True                 | True            |
| rich_country            | country_short           |          34 |               5 |        0.312454  |     0.161042   | STRATIFIED_WITHIN_BLOCK_MC_PERMUTATION |          20000 |                0.8 |     0.172562  |     0.418427  |                   35 |    0.292804  | False                | False           |
| rich_country            | family_long             |          34 |               5 |        0.676007  |     0.00114994 | STRATIFIED_WITHIN_BLOCK_MC_PERMUTATION |          20000 |                1   |     0.622676  |     0.801667  |                   42 |    0.0139993 | True                 | True            |
| rich_country            | family_short            |          34 |               5 |        0.441026  |     0.0419479  | STRATIFIED_WITHIN_BLOCK_MC_PERMUTATION |          20000 |                1   |     0.331746  |     0.564762  |                   35 |    0.0932176 | False                | False           |

## Внешняя валидизация по типам групп

| validation_metric       | expectation_construct   | group_type       |   n |   spearman_rho |
|:------------------------|:------------------------|:-----------------|----:|---------------:|
| current_global_attitude | country_long            | age              |   4 |     -0.4       |
| current_global_attitude | country_long            | age_education    |   2 |    nan         |
| current_global_attitude | country_long            | education        |   3 |     -0.5       |
| current_global_attitude | country_long            | employment       |   2 |    nan         |
| current_global_attitude | country_long            | federal_district |   8 |     -0.404762  |
| current_global_attitude | country_long            | gender           |   2 |    nan         |
| current_global_attitude | country_long            | material_status  |   5 |      0.9       |
| current_global_attitude | country_long            | media_source     |   2 |    nan         |
| current_global_attitude | country_long            | settlement       |   6 |     -0.6       |
| current_global_attitude | country_short           | age              |   4 |     -0.4       |
| current_global_attitude | country_short           | age_education    |   2 |    nan         |
| current_global_attitude | country_short           | education        |   3 |      1         |
| current_global_attitude | country_short           | employment       |   2 |    nan         |
| current_global_attitude | country_short           | federal_district |   8 |     -0.047619  |
| current_global_attitude | country_short           | gender           |   2 |    nan         |
| current_global_attitude | country_short           | material_status  |   5 |      0.9       |
| current_global_attitude | country_short           | media_source     |   2 |    nan         |
| current_global_attitude | country_short           | settlement       |   6 |     -0.0857143 |
| current_global_attitude | family_long             | age              |   4 |      0.8       |
| current_global_attitude | family_long             | age_education    |   2 |    nan         |
| current_global_attitude | family_long             | education        |   3 |     -0.5       |
| current_global_attitude | family_long             | employment       |   2 |    nan         |
| current_global_attitude | family_long             | federal_district |   8 |      0.428571  |
| current_global_attitude | family_long             | gender           |   2 |    nan         |
| current_global_attitude | family_long             | material_status  |   5 |      0.9       |
| current_global_attitude | family_long             | media_source     |   2 |    nan         |
| current_global_attitude | family_long             | settlement       |   6 |     -0.714286  |
| current_global_attitude | family_short            | age              |   4 |      0.8       |
| current_global_attitude | family_short            | age_education    |   2 |    nan         |
| current_global_attitude | family_short            | education        |   3 |      0.5       |
| current_global_attitude | family_short            | employment       |   2 |    nan         |
| current_global_attitude | family_short            | federal_district |   8 |      0.761905  |
| current_global_attitude | family_short            | gender           |   2 |    nan         |
| current_global_attitude | family_short            | material_status  |   5 |      0.9       |
| current_global_attitude | family_short            | media_source     |   2 |    nan         |
| current_global_attitude | family_short            | settlement       |   6 |     -0.428571  |
| developed_country       | country_long            | age              |   4 |      0.4       |
| developed_country       | country_long            | age_education    |   2 |    nan         |
| developed_country       | country_long            | education        |   3 |      0.5       |
| developed_country       | country_long            | employment       |   2 |    nan         |
| developed_country       | country_long            | federal_district |   8 |      0.547619  |
| developed_country       | country_long            | gender           |   2 |    nan         |
| developed_country       | country_long            | material_status  |   5 |      1         |
| developed_country       | country_long            | media_source     |   2 |    nan         |
| developed_country       | country_long            | settlement       |   6 |      0.257143  |
| developed_country       | country_short           | age              |   4 |      0.4       |
| developed_country       | country_short           | age_education    |   2 |    nan         |
| developed_country       | country_short           | education        |   3 |      0.5       |
| developed_country       | country_short           | employment       |   2 |    nan         |
| developed_country       | country_short           | federal_district |   8 |      0.357143  |
| developed_country       | country_short           | gender           |   2 |    nan         |
| developed_country       | country_short           | material_status  |   5 |      1         |
| developed_country       | country_short           | media_source     |   2 |    nan         |
| developed_country       | country_short           | settlement       |   6 |      0.428571  |
| developed_country       | family_long             | age              |   4 |      0.8       |
| developed_country       | family_long             | age_education    |   2 |    nan         |
| developed_country       | family_long             | education        |   3 |      0.5       |
| developed_country       | family_long             | employment       |   2 |    nan         |
| developed_country       | family_long             | federal_district |   8 |      0.904762  |
| developed_country       | family_long             | gender           |   2 |    nan         |
| developed_country       | family_long             | material_status  |   5 |      1         |
| developed_country       | family_long             | media_source     |   2 |    nan         |
| developed_country       | family_long             | settlement       |   6 |      0.0285714 |
| developed_country       | family_short            | age              |   4 |      0.8       |
| developed_country       | family_short            | age_education    |   2 |    nan         |
| developed_country       | family_short            | education        |   3 |      1         |
| developed_country       | family_short            | employment       |   2 |    nan         |
| developed_country       | family_short            | federal_district |   8 |      0.0238095 |
| developed_country       | family_short            | gender           |   2 |    nan         |
| developed_country       | family_short            | material_status  |   5 |      1         |
| developed_country       | family_short            | media_source     |   2 |    nan         |
| developed_country       | family_short            | settlement       |   6 |      0.257143  |
| global_attitude         | country_long            | age              |   4 |      0.4       |
| global_attitude         | country_long            | age_education    |   2 |    nan         |
| global_attitude         | country_long            | education        |   3 |     -0.5       |
| global_attitude         | country_long            | employment       |   2 |    nan         |
| global_attitude         | country_long            | federal_district |   8 |      0.47619   |
| global_attitude         | country_long            | gender           |   2 |    nan         |
| global_attitude         | country_long            | material_status  |   5 |      1         |
| global_attitude         | country_long            | media_source     |   2 |    nan         |
| global_attitude         | country_long            | settlement       |   6 |     -0.6       |
| global_attitude         | country_short           | age              |   4 |      0.4       |
| global_attitude         | country_short           | age_education    |   2 |    nan         |
| global_attitude         | country_short           | education        |   3 |      1         |
| global_attitude         | country_short           | employment       |   2 |    nan         |
| global_attitude         | country_short           | federal_district |   8 |      0.333333  |
| global_attitude         | country_short           | gender           |   2 |    nan         |
| global_attitude         | country_short           | material_status  |   5 |      1         |
| global_attitude         | country_short           | media_source     |   2 |    nan         |
| global_attitude         | country_short           | settlement       |   6 |      0.257143  |
| global_attitude         | family_long             | age              |   4 |     -0.8       |
| global_attitude         | family_long             | age_education    |   2 |    nan         |
| global_attitude         | family_long             | education        |   3 |     -0.5       |
| global_attitude         | family_long             | employment       |   2 |    nan         |
| global_attitude         | family_long             | federal_district |   8 |      0.738095  |
| global_attitude         | family_long             | gender           |   2 |    nan         |
| global_attitude         | family_long             | material_status  |   5 |      1         |
| global_attitude         | family_long             | media_source     |   2 |    nan         |
| global_attitude         | family_long             | settlement       |   6 |     -0.885714  |
| global_attitude         | family_short            | age              |   4 |     -0.8       |
| global_attitude         | family_short            | age_education    |   2 |    nan         |
| global_attitude         | family_short            | education        |   3 |      0.5       |
| global_attitude         | family_short            | employment       |   2 |    nan         |
| global_attitude         | family_short            | federal_district |   8 |      0.309524  |
| global_attitude         | family_short            | gender           |   2 |    nan         |
| global_attitude         | family_short            | material_status  |   5 |      1         |
| global_attitude         | family_short            | media_source     |   2 |    nan         |
| global_attitude         | family_short            | settlement       |   6 |     -0.257143  |
| global_influence        | country_long            | age              |   4 |     -0.2       |
| global_influence        | country_long            | age_education    |   2 |    nan         |
| global_influence        | country_long            | education        |   3 |     -0.5       |
| global_influence        | country_long            | employment       |   2 |    nan         |
| global_influence        | country_long            | federal_district |   8 |      0.619048  |
| global_influence        | country_long            | gender           |   2 |    nan         |
| global_influence        | country_long            | material_status  |   5 |      0.9       |
| global_influence        | country_long            | media_source     |   2 |    nan         |
| global_influence        | country_long            | settlement       |   6 |     -0.6       |
| global_influence        | country_short           | age              |   4 |     -0.2       |
| global_influence        | country_short           | age_education    |   2 |    nan         |
| global_influence        | country_short           | education        |   3 |     -0.5       |

## Ожидания ↔ тревоги: permutation + FDR

| anxiety_subject   | anxiety_item                                                        | expectation_construct   |   n |   spearman_rho |   p_value_perm |   p_value_asymptotic | test_method             |   permutations |   q_fdr_perm | significant_fdr_05   |
|:------------------|:--------------------------------------------------------------------|:------------------------|----:|---------------:|---------------:|---------------------:|:------------------------|---------------:|-------------:|:---------------------|
| country           | угроза нападения других государств                                  | country_long            |   9 |     0.445394   |      0.228477  |            0.22958   | MONTE_CARLO_PERMUTATION |          10000 |     0.70403  | False                |
| country           | угроза нападения других государств                                  | country_short           |   9 |     0.516667   |      0.159384  |            0.15439   | MONTE_CARLO_PERMUTATION |          10000 |     0.70403  | False                |
| country           | угроза нападения других государств                                  | family_long             |   9 |     0.5        |      0.182982  |            0.170471  | MONTE_CARLO_PERMUTATION |          10000 |     0.70403  | False                |
| country           | угроза нападения других государств                                  | family_short            |   9 |     0.443519   |      0.234677  |            0.231784  | MONTE_CARLO_PERMUTATION |          10000 |     0.70403  | False                |
| country           | повышение цен, обнищание людей                                      | country_long            |   9 |    -0.237288   |      0.534447  |            0.538712  | MONTE_CARLO_PERMUTATION |          10000 |     0.863756 | False                |
| country           | повышение цен, обнищание людей                                      | country_short           |   9 |    -0.378165   |      0.311669  |            0.315613  | MONTE_CARLO_PERMUTATION |          10000 |     0.741387 | False                |
| country           | повышение цен, обнищание людей                                      | family_long             |   9 |    -0.294128   |      0.442756  |            0.442341  | MONTE_CARLO_PERMUTATION |          10000 |     0.856947 | False                |
| country           | повышение цен, обнищание людей                                      | family_short            |   9 |    -0.337556   |      0.363664  |            0.374331  | MONTE_CARLO_PERMUTATION |          10000 |     0.808141 | False                |
| country           | межнациональные конфликты                                           | country_long            |   9 |     0.578064   |      0.110789  |            0.103025  | MONTE_CARLO_PERMUTATION |          10000 |     0.664734 | False                |
| country           | межнациональные конфликты                                           | country_short           |   9 |     0.610884   |      0.0835916 |            0.0805418 | MONTE_CARLO_PERMUTATION |          10000 |     0.664734 | False                |
| country           | межнациональные конфликты                                           | family_long             |   9 |     0.585779   |      0.10419   |            0.0974339 | MONTE_CARLO_PERMUTATION |          10000 |     0.664734 | False                |
| country           | межнациональные конфликты                                           | family_short            |   9 |     0.491597   |      0.189181  |            0.178927  | MONTE_CARLO_PERMUTATION |          10000 |     0.70403  | False                |
| country           | угроза гражданской войны                                            | country_long            |   9 |    -0.0590723  |      0.875212  |            0.880008  | MONTE_CARLO_PERMUTATION |          10000 |     0.972458 | False                |
| country           | угроза гражданской войны                                            | country_short           |   9 |    -0.142261   |      0.712529  |            0.715032  | MONTE_CARLO_PERMUTATION |          10000 |     0.927437 | False                |
| country           | угроза гражданской войны                                            | family_long             |   9 |    -0.0251048  |      0.957004  |            0.948884  | MONTE_CARLO_PERMUTATION |          10000 |     0.990418 | False                |
| country           | угроза гражданской войны                                            | family_short            |   9 |    -0.193277   |      0.617038  |            0.618311  | MONTE_CARLO_PERMUTATION |          10000 |     0.881354 | False                |
| country           | рост терроризма (взрывы, поджоги, похищения людей и т.п.)           | country_long            |   9 |     0.18488    |      0.631637  |            0.633928  | MONTE_CARLO_PERMUTATION |          10000 |     0.881354 | False                |
| country           | рост терроризма (взрывы, поджоги, похищения людей и т.п.)           | country_short           |   9 |     0.383333   |      0.309269  |            0.308495  | MONTE_CARLO_PERMUTATION |          10000 |     0.741387 | False                |
| country           | рост терроризма (взрывы, поджоги, похищения людей и т.п.)           | family_long             |   9 |     0.216667   |      0.581642  |            0.575515  | MONTE_CARLO_PERMUTATION |          10000 |     0.881354 | False                |
| country           | рост терроризма (взрывы, поджоги, похищения людей и т.п.)           | family_short            |   9 |     0.518833   |      0.160384  |            0.152367  | MONTE_CARLO_PERMUTATION |          10000 |     0.70403  | False                |
| personal          | здоровье близких                                                    | country_long            |   9 |    -0.0506334  |      0.90301   |            0.897071  | MONTE_CARLO_PERMUTATION |          10000 |     0.985101 | False                |
| personal          | здоровье близких                                                    | country_short           |   9 |    -0.24268    |      0.531947  |            0.529241  | MONTE_CARLO_PERMUTATION |          10000 |     0.863756 | False                |
| personal          | здоровье близких                                                    | family_long             |   9 |    -0.092051   |      0.813519  |            0.813794  | MONTE_CARLO_PERMUTATION |          10000 |     0.938675 | False                |
| personal          | здоровье близких                                                    | family_short            |   9 |    -0.310924   |      0.412659  |            0.415425  | MONTE_CARLO_PERMUTATION |          10000 |     0.842516 | False                |
| personal          | страх за детей (внуков)                                             | country_long            |   9 |    -0.037975   |      0.922508  |            0.922731  | MONTE_CARLO_PERMUTATION |          10000 |     0.988401 | False                |
| personal          | страх за детей (внуков)                                             | country_short           |   9 |    -0.175734   |      0.650335  |            0.651084  | MONTE_CARLO_PERMUTATION |          10000 |     0.88682  | False                |
| personal          | страх за детей (внуков)                                             | family_long             |   9 |     0          |      1         |            1         | MONTE_CARLO_PERMUTATION |          10000 |     1        | False                |
| personal          | страх за детей (внуков)                                             | family_short            |   9 |    -0.235294   |      0.547045  |            0.54223   | MONTE_CARLO_PERMUTATION |          10000 |     0.863756 | False                |
| personal          | собственное здоровье                                                | country_long            |   9 |     0.114895   |      0.767223  |            0.768498  | MONTE_CARLO_PERMUTATION |          10000 |     0.927437 | False                |
| personal          | собственное здоровье                                                | country_short           |   9 |     0.202548   |      0.60124   |            0.601221  | MONTE_CARLO_PERMUTATION |          10000 |     0.881354 | False                |
| personal          | собственное здоровье                                                | family_long             |   9 |     0.109713   |      0.782622  |            0.778723  | MONTE_CARLO_PERMUTATION |          10000 |     0.927437 | False                |
| personal          | собственное здоровье                                                | family_short            |   9 |     0.18221    |      0.616938  |            0.638922  | MONTE_CARLO_PERMUTATION |          10000 |     0.881354 | False                |
| personal          | безденежье                                                          | country_long            |   9 |    -0.464139   |      0.206879  |            0.208183  | MONTE_CARLO_PERMUTATION |          10000 |     0.70403  | False                |
| personal          | безденежье                                                          | country_short           |   9 |    -0.627621   |      0.0765923 |            0.070365  | MONTE_CARLO_PERMUTATION |          10000 |     0.664734 | False                |
| personal          | безденежье                                                          | family_long             |   9 |    -0.476992   |      0.193781  |            0.194179  | MONTE_CARLO_PERMUTATION |          10000 |     0.70403  | False                |
| personal          | безденежье                                                          | family_short            |   9 |    -0.672269   |      0.0548945 |            0.0472857 | MONTE_CARLO_PERMUTATION |          10000 |     0.664734 | False                |
| personal          | страх перед терактами (взрывы домов, диверсии на транспорте и т.п.) | country_long            |   9 |     0.374471   |      0.321268  |            0.320749  | MONTE_CARLO_PERMUTATION |          10000 |     0.741387 | False                |
| personal          | страх перед терактами (взрывы домов, диверсии на транспорте и т.п.) | country_short           |   9 |     0.531688   |      0.149885  |            0.140683  | MONTE_CARLO_PERMUTATION |          10000 |     0.70403  | False                |
| personal          | страх перед терактами (взрывы домов, диверсии на транспорте и т.п.) | family_long             |   9 |     0.447293   |      0.223478  |            0.22736   | MONTE_CARLO_PERMUTATION |          10000 |     0.70403  | False                |
| personal          | страх перед терактами (взрывы домов, диверсии на транспорте и т.п.) | family_short            |   9 |     0.699178   |      0.0447955 |            0.0360816 | MONTE_CARLO_PERMUTATION |          10000 |     0.664734 | False                |
| world             | ядерная война                                                       | country_long            |   9 |     0.302532   |      0.421258  |            0.42878   | MONTE_CARLO_PERMUTATION |          10000 |     0.842516 | False                |
| world             | ядерная война                                                       | country_short           |   9 |     0.416667   |      0.268773  |            0.264586  | MONTE_CARLO_PERMUTATION |          10000 |     0.733018 | False                |
| world             | ядерная война                                                       | family_long             |   9 |     0.383333   |      0.311569  |            0.308495  | MONTE_CARLO_PERMUTATION |          10000 |     0.741387 | False                |
| world             | ядерная война                                                       | family_short            |   9 |     0.426782   |      0.249875  |            0.251957  | MONTE_CARLO_PERMUTATION |          10000 |     0.713929 | False                |
| world             | массовые эпидемии, распространение СПИДа, КОВИДа и др.              | country_long            |   9 |     0.324897   |      0.379362  |            0.393616  | MONTE_CARLO_PERMUTATION |          10000 |     0.812919 | False                |
| world             | массовые эпидемии, распространение СПИДа, КОВИДа и др.              | country_short           |   9 |     0.284521   |      0.457854  |            0.458069  | MONTE_CARLO_PERMUTATION |          10000 |     0.858477 | False                |
| world             | массовые эпидемии, распространение СПИДа, КОВИДа и др.              | family_long             |   9 |     0.259416   |      0.49795   |            0.500268  | MONTE_CARLO_PERMUTATION |          10000 |     0.863756 | False                |
| world             | массовые эпидемии, распространение СПИДа, КОВИДа и др.              | family_short            |   9 |     0.239496   |      0.529547  |            0.534826  | MONTE_CARLO_PERMUTATION |          10000 |     0.863756 | False                |
| world             | химическое и радиационное заражение воды, воздуха, продуктов        | country_long            |   9 |    -0.145304   |      0.713929  |            0.709147  | MONTE_CARLO_PERMUTATION |          10000 |     0.927437 | False                |
| world             | химическое и радиационное заражение воды, воздуха, продуктов        | country_short           |   9 |    -0.135613   |      0.732527  |            0.727931  | MONTE_CARLO_PERMUTATION |          10000 |     0.927437 | False                |
| world             | химическое и радиационное заражение воды, воздуха, продуктов        | family_long             |   9 |    -0.0847579  |      0.837916  |            0.828363  | MONTE_CARLO_PERMUTATION |          10000 |     0.948584 | False                |
| world             | химическое и радиационное заражение воды, воздуха, продуктов        | family_short            |   9 |    -0.12767    |      0.746225  |            0.74342   | MONTE_CARLO_PERMUTATION |          10000 |     0.927437 | False                |
| world             | засорение планеты отходами                                          | country_long            |   9 |    -0.652542   |      0.0656934 |            0.0567698 | MONTE_CARLO_PERMUTATION |          10000 |     0.664734 | False                |
| world             | засорение планеты отходами                                          | country_short           |   9 |    -0.663889   |      0.0568943 |            0.0511799 | MONTE_CARLO_PERMUTATION |          10000 |     0.664734 | False                |
| world             | засорение планеты отходами                                          | family_long             |   9 |    -0.680696   |      0.0481952 |            0.0435662 | MONTE_CARLO_PERMUTATION |          10000 |     0.664734 | False                |
| world             | засорение планеты отходами                                          | family_short            |   9 |    -0.594942   |      0.0946905 |            0.0910394 | MONTE_CARLO_PERMUTATION |          10000 |     0.664734 | False                |
| world             | международный терроризм                                             | country_long            |   9 |    -0.00843889 |      0.986401  |            0.982809  | MONTE_CARLO_PERMUTATION |          10000 |     1        | False                |
| world             | международный терроризм                                             | country_short           |   9 |     0.108788   |      0.788321  |            0.780554  | MONTE_CARLO_PERMUTATION |          10000 |     0.927437 | False                |
| world             | международный терроризм                                             | family_long             |   9 |     0.0251048  |      0.957404  |            0.948884  | MONTE_CARLO_PERMUTATION |          10000 |     0.990418 | False                |
| world             | международный терроризм                                             | family_short            |   9 |     0.243697   |      0.524148  |            0.527461  | MONTE_CARLO_PERMUTATION |          10000 |     0.863756 | False                |

## ML

Нет данных для расчета.

## Правила интерпретации

- Микро–макро разрыв относится к одной полевой волне; p-value для малых n рассчитывается exact permutation.
- Контраст short/long относится к соседним независимым волнам и не является панельным эффектом.
- Theil–Sen трактуется как монотонный тренд только если bootstrap 95% CI не включает 0.
- Change-point — описательный структурный сдвиг по 10 годовым точкам; метод: точное penalized dynamic programming L2 (`EXACT_DP_L2`), не PELT.
- Тревоги — множественный выбор; доли не образуют единый суммарный индекс.
- Кластеры — предварительная типология опубликованных социальных срезов; интерпретируются только вместе с bootstrap/LOO/seed ARI.
- Внешняя валидизация использует перестановки только внутри `group_type`; итоговая robust-метка дополнительно требует согласованности направлений между блоками.
- ML/SHAP не запускается на агрегированных таблицах.
- Источник каждого обязательного блока фиксируется как LIVE или EMBEDDED_OFFICIAL_SNAPSHOT.